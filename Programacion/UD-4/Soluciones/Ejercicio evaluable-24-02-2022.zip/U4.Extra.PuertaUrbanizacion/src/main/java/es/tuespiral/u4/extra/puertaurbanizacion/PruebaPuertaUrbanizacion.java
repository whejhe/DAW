package es.tuespiral.u4.extra.puertaurbanizacion;

import java.util.Scanner;

public class PruebaPuertaUrbanizacion {
    public static void main(String[] args) {
        PuertaUrbanizacion p = new PuertaUrbanizacion();
        muestraMenu(p);
    }

    private static void muestraMenu(PuertaUrbanizacion p) {
        Scanner sc = new Scanner(System.in);
        int opcion;
        int identificadorTarjeta;
        
        do {
            System.out.println("\n0 - Cerrar programa");
            System.out.println("1 - Agregar tarjeta permitida");
            System.out.println("2 - Eliminar tarjeta permitida");
            System.out.println("3 - Muestra las tarjetas permitidas");
            System.out.println("4 - Intentar entrar en la urbanización");
            System.out.println("5 - Intentar salir de la urbanización");
            System.out.println("Elige una opción: ");
            opcion = sc.nextInt();
            
            switch(opcion) {
                case 0: 
                    break;
                case 1:
                    System.out.println("Vas a agregar una nueva tarjeta permitida al sistema");
                    identificadorTarjeta = pideIdentificadorTarjeta();
                    String nombrePropietario = pidePropietarioTarjeta();
                    p.agregaTarjetaPermitida(new Tarjeta(identificadorTarjeta, nombrePropietario));
                    break;
                case 2:
                    System.out.println("Vas a eliminar una tarjeta permitida del sistema");
                    identificadorTarjeta = pideIdentificadorTarjeta();
                    p.eliminaTarjetaPermitida(identificadorTarjeta);
                    break;
                case 3:
                    System.out.println("Los tarjetas permitidas son: ");
                    p.imprimeTarjetasPermitidas();
                    break;
                case 4: 
                    identificadorTarjeta = pideIdentificadorTarjeta();
                    p.intentoDeEntrada(identificadorTarjeta);
                    break;
                case 5:
                    identificadorTarjeta = pideIdentificadorTarjeta();
                    p.intentoDeSalida(identificadorTarjeta);
                    break;
                
                default:
                    System.out.println("Opción incorrecta");
            }
            
        } while(opcion != 0);
    }

    private static int pideIdentificadorTarjeta() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce el número identificador de la tarjeta");
        return sc.nextInt();
    }
    
    private static String pidePropietarioTarjeta() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce el nombre del propietario de la tarjeta");
        return sc.nextLine();
    }

}

