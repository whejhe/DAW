package es.tuespiral.u4.extra.puertaurbanizacion;

public class Tarjeta {
    private final int identificador;
    private String nombrePropietario;

    public Tarjeta(int identificador, String nombrePropietario) {
        this.identificador = identificador;
        this.nombrePropietario = nombrePropietario;
    }
    
    public String getNombrePropietario() {
        return nombrePropietario;
    }

    public int getIdentificador() {
        return identificador;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 13 * hash + this.identificador;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Tarjeta other = (Tarjeta) obj;
        if (this.identificador != other.identificador) {
            return false;
        }
        return true;
    }
    
    

}
