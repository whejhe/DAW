package es.tuespiral.u4.extra.puertaurbanizacion;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class PuertaUrbanizacion {
    private Set<Tarjeta> tarjetasDentro;
    private Map<Integer, Tarjeta> tarjetasPermitidas;
            
    public PuertaUrbanizacion() {
        tarjetasDentro = new HashSet<>();
        tarjetasPermitidas = new HashMap<>();
    }
    
    public void agregaTarjetaPermitida(Tarjeta t) {
        if(!tarjetasPermitidas.containsKey(t.getIdentificador())) {
            tarjetasPermitidas.put(t.getIdentificador(), t);
            System.out.println("La tarjeta "+t.getIdentificador()+" se agregó correctamente");
        } else {
            System.out.println("ERROR: la tarjeta "+t.getIdentificador()+" ya estaba incluida en el sistema");
        }
    }
    
    public void eliminaTarjetaPermitida(int identificador) {
        if(tarjetasPermitidas.containsKey(identificador)) {
            tarjetasPermitidas.remove(identificador);
            System.out.println("La tarjeta "+identificador+" se eliminó correctamente");
        } else {
            System.out.println("ERROR: la tarjeta de NO estaba incluida en el sistema y no se puede eliminar");
        }
    }
    
    public void intentoDeEntrada(int identificador) {
        if(tarjetasPermitidas.containsKey(identificador)) {
            Tarjeta t = tarjetasPermitidas.get(identificador);
            if(tarjetasDentro.contains(t)) {
                System.out.println("ERROR: el propietario/a "+t.getNombrePropietario()+" ya tiene un vehiculo dentro de la urbanización");
            } else {
                tarjetasDentro.add(t);
                System.out.println("El propietario/a "+t.getNombrePropietario()+" ENTRA con su vehiculo");
            }
        } else {
            System.out.println("ERROR: la tarjeta con identificador "+identificador+" no está permitida");
        }
    }
    
    public void intentoDeSalida(int identificador) {
        
        if(tarjetasPermitidas.containsKey(identificador)) {
            Tarjeta t = tarjetasPermitidas.get(identificador);
            if(!tarjetasDentro.contains(t)) {
                System.out.println("ERROR: el propietario/a "+t.getNombrePropietario()+" no tiene un vehiculo dentro de la urbanización");
            } else {
                tarjetasDentro.remove(t);
                System.out.println("El propietario/a "+t.getNombrePropietario()+" SALE con su vehiculo de la urbanización");
            }
        } else {
            System.out.println("ERROR: la tarjeta con identificador "+identificador+" no está permitida");
        }
    }
    
    public void imprimeTarjetasPermitidas() {
        if (tarjetasPermitidas.isEmpty()) {
            System.out.println("Actualmente no hay tarjetas permitidas");
        } else {
            Iterator<Integer> iter = tarjetasPermitidas.keySet().iterator();
            while(iter.hasNext()) {
                Tarjeta t = tarjetasPermitidas.get(iter.next());
                System.out.println(t.getIdentificador()+" - "+t.getNombrePropietario());
            }
        }
    }
    
}
