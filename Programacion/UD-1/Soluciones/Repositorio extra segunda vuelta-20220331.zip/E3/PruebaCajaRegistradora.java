
package com.mycompany.u1.extra.cajaregistradora;

public class PruebaCajaRegistradora {
    public static void main(String[] args) {
        CajaRegistradora c1=new CajaRegistradora();
        c1.abrirCaja();
        c1.nuevoCliente();
        c1.registrarArticulo(12.95);
        c1.registrarArticulo(2.48);
        c1.registrarArticulo(20.06);
        c1.imprimirTicketCliente();
        //nuevo cliente. Se puede seguir usando c1
        CajaRegistradora c2=new CajaRegistradora();
        c2.nuevoCliente();
        c2.registrarArticulo(5.95);
        c2.registrarArticulo(2.48);
        c2.registrarArticulo(2.48);
        c2.registrarArticulo(7.88);
        c2.imprimirTicketCliente();
    }
}
