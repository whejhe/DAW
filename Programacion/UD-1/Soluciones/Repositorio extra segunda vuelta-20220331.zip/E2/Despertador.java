
package com.mycompany.u1.extra.despertador;

public class Despertador {
    //propiedades
    public int numHora;
    public int numMinutos;
    public int numHoraAlarm;
    public int numMinAlarm;
    public boolean activada;
    //métodos
    public void setHora(int hora, int minutos){
        numHora=hora;
        numMinutos=minutos; 
    } 
    public void setHoraAlarma(int horaAlarm, int minAlarm){
        numHoraAlarm = horaAlarm;
        numMinAlarm = minAlarm;
    } 

    public int getHoraActual() {
        return numHora;
    }

    public int getMinActual() {
        return numMinutos;
    }

    public int getHoraAlarma() {
        return numHoraAlarm;
    }

    public int getMinAlarma() {
        return numMinAlarm;
    }
   public void activarAlarma(){
       activada = true;
   }
    public void desactivarAlarma(){
        activada = false;
    }
    public void sonarAlarma(){
        System.out.println("PI PI PI PI... PI PI PI PI");
    }
    public void imprimirHoraActual(){
        System.out.println("La hora actual es: "+numHora+":"+numMinutos);
    }
    public void imprimirHoraAlarma(){
        System.out.println("La hora de la alarma es: "+numHoraAlarm+":"+numMinAlarm);
    }
    public void imprimirEstadoAlarma(){
        System.out.println("¿Está activada la alarma? "+activada);
    } 
}
