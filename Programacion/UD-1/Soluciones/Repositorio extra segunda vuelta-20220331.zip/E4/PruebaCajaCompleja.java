
package com.mycompany.u1.extra.cajaregistradora;

public class PruebaCajaCompleja {
    public static void main(String[] args) {
        CajaRegistradora c1=new CajaRegistradora();
        c1.abrirCaja();
        c1.nuevoCliente();
        c1.registrarArticulo(20);
        c1.anulaArticulo(20);
        c1.registrarArticulo(12);
        c1.registrarArticulo(34);
        c1.registrarArticulo(16);
        c1.imprimirTicketCliente();
        c1.nuevoCliente();
        c1.registrarArticulo(10);
        c1.registrarArticulo(5);
        c1.imprimirTicketCliente();
        c1.imprimeCierreCaja();
        System.out.println("El importe medio por cliente es: "+c1.calculaImporteMedioPorCliente());
        System.out.println("El precio medio por artículo es: "+ c1.calculaPrecioMedioArticulosVendidos());
    }
}
