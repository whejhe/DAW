
package com.mycompany.u1.extra.cajaregistradora;

public class CajaRegistradora {
    public double importeCliente;
    public int numArticulosCliente;
    public int numClientesAtendidos;
    public double importeTotalCaja;
    public int numArticulosVendidos;
    
    public void abrirCaja(){
        importeCliente=0;
        numArticulosCliente=0;
        numClientesAtendidos=0;
        importeTotalCaja=0;
        numArticulosVendidos=0;
    }
    public void nuevoCliente(){
        importeCliente=0;
        numArticulosCliente=0;
        numClientesAtendidos++;
    }
    public void registrarArticulo (double precio){
        numArticulosCliente++;//numArticulosCliente=numArticulosCliente+1;
        importeCliente = precio + importeCliente;
        numArticulosVendidos++;
        importeTotalCaja = importeTotalCaja + precio;
        
    }
    
    public void anulaArticulo(double precio){
        numArticulosCliente--;
        importeCliente = importeCliente - precio;
        numArticulosVendidos--;
        //numArticulosVendidos = numArticulosVendidos - 1;
        importeTotalCaja = importeTotalCaja - precio;
        
    }
    
    public void imprimirTicketCliente(){
        System.out.println("El cliente ha comprado " +numArticulosCliente+" artículos por un precio total de "+importeCliente+" euros");
    }
    public void imprimeCierreCaja(){
        System.out.println("Se han vendido un total de "+numArticulosVendidos+" artículos por un importe total de"+importeTotalCaja+" euros");
    }
    public double calculaPrecioMedioArticulosVendidos(){
        double precio=importeTotalCaja/numArticulosVendidos;
        return precio;
        //return importeTotalCaja/numArticulosVendidos;
    }
   /* public double calculaImporteMedioPorCliente(){
        double precio=importeCliente/numArticulosCliente;
        return precio;
    }*/
    //Posibilidad 2 para calculaImporteMedioPorCliente
     public double calculaImporteMedioPorCliente(){
        double precio=importeTotalCaja/numClientesAtendidos;
        return precio;
    }
}
