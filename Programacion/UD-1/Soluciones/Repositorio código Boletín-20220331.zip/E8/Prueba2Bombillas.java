
package com.mycompany.u1.e7.bombilla;

public class Prueba2Bombillas {
    public static void main(String[] args) {
         BombillaInteligente led1= new BombillaInteligente();
         BombillaInteligente led2 = new BombillaInteligente();
         
         led1.encender();
         led1.apagar();
         led1.encender();
         led1.apagar();
         led1.encender();
         led1.apagar();
         
         led2.encender();
         led2.apagar();
         System.out.println("Se ha encendido: "+led1.obtieneNumVecesEncendida()+" veces");
         System.out.println("Se ha encendido: "+led2.obtieneNumVecesEncendida()+" veces");
    }
    
}
