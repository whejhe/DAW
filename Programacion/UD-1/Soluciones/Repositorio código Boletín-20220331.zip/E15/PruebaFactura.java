
package com.mycompany.u1.e15.factura;
import java.util.Scanner;

public class PruebaFactura {
    public static void main(String[] args) {
        final double IVA = 21;
        Scanner sc = new Scanner(System.in);
        double precio;
        int numPen;
        System.out.println("Dime el precio de un pen-drive");
        precio=sc.nextDouble();
        System.out.println("Dime el número de pen-drives que quieres comprar");
        numPen=sc.nextInt();
        
        //Simula la factura
        System.out.println("FACTURA JAMAZON");
        System.out.println("Precio unitario: "+precio+" €");
        System.out.println("Número de artículos: "+numPen);
        double resultadoSinIva = numPen * precio;
        System.out.println("Subtotal: "+resultadoSinIva+" €");
        System.out.println("---------------------");
        double resultadoConIva;
        resultadoConIva = resultadoSinIva + resultadoSinIva*IVA/100;
        //resultadoConIva = resultadoSinIva * (100+IVA)/100;
        //resultadoConIva = resultadoSinIva + (IVA*resultadoSinIva)/100;
        System.out.println("Total (IVA incluido): "+resultadoConIva+" €");
        
    }  
    
}
