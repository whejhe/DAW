
package com.mycompany.u1.e4.persona;

public class PruebaPersona {
   public static void main(String[] args) {
        Persona p1;
        p1 = new Persona();
        Persona p2 = new Persona();
        
        //  Cambiaremos el nombre de p1 por "Pepe" y su edad por 18.
        p1.cambiaNombre("Pepe");
        p1.cambiaEdad(18);
        
        //• Cambiaremos el nombre de p2 por "Pepa" y su edad por 19.
        p2.cambiaNombre("Pepa");
        p2.cambiaEdad(19);
        
        //• Imprimir el nombre, la edad, el estado laboral y el estado civil de "Pepe"
        p1.imprimeNombre();
        p1.imprimeEdad();
        p1.imprimeEstadoTrabajo();
        p1.imprimeEstadoCivil();
        
        //• Imprimir el nombre, la edad, el estado laboral y el estado civil de "Pepa"
        p2.imprimeNombre();
        p2.imprimeEdad();
        p2.imprimeEstadoTrabajo();
        p2.imprimeEstadoCivil();
        
        //Ahora "Pepe" consigue un trabajo, después lo pierde y consigue otro trabajo de nuevo.
        p1.consigueTrabajo();
        p1.pierdeTrabajo();
        p1.consigueTrabajo();
        
        //◦ "Pepa" consigue un trabajo.
        p2.consigueTrabajo();
        //◦ Cambiamos la edad de "Pepe" y "Pepa", ahora tienen 30 y 31
        p1.cambiaEdad(30);
        p2.cambiaEdad(31);
        //◦ "Pepe" se casa y "Pepa" también
        p1.seCasa();
        p2.seCasa();

        //◦ "Pepe" se divorcia, pero "Pepa" no.
        p1.seDivorcia();
        
        //◦ Imprimir el nombre, la edad, el estado laboral y el estado civil de "Pepe"
        p1.imprimeNombre();
        p1.imprimeEdad();
        p1.imprimeEstadoTrabajo();
        p1.imprimeEstadoCivil();
        //◦ Imprimir el nombre, la edad, el estado laboral y el estado civil de "Pepa"
        p2.imprimeNombre();
        p2.imprimeEdad();
        p2.imprimeEstadoTrabajo();
        p2.imprimeEstadoCivil();
        
    }
 
}
