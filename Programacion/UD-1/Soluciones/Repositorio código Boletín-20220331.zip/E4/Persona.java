
package com.mycompany.u1.e4.persona;


public class Persona {
    // PROPIEDADES
    public String nombre;
    public int edad;
    public boolean trabaja;
    public boolean casada;
    
    
    // MÉTODOS
    public void cambiaNombre(String nuevoNombre) {
       //INSTRUCCIONES
       nombre = nuevoNombre;
    }
    
    public void imprimeNombre () {
        System.out.println("Nombre: "+nombre);
    }
    
    public void cambiaEdad (int nuevaEdad) {
        edad = nuevaEdad;
    }
    
    public void imprimeEdad () {
        System.out.println("La edad es: "+edad);
    }
    
    public void consigueTrabajo () {
        trabaja = true;
    }
    public void pierdeTrabajo () {
        trabaja = false;
    }
    
    public void imprimeEstadoTrabajo () {
        System.out.println("Trabaja?: "+trabaja);
    }
    
    public void seCasa () {
        casada = true;
    }
    public void seDivorcia () {
        casada = false;
    }
    public void imprimeEstadoCivil () {
        System.out.println("Esta casada: "+casada);
    }
    
    public void cumpleAnios() {
        edad++;
        // edad = edad + 1;
    }
    
    public int obtieneNumAnios() {
        return edad;
    }

}
