
package com.mycompany.u1.e14.exprexiones;
import java.util.Scanner;
public class Expresiones {
    public static void main(String[] args) {
        double a, b, c, d;
        double r1, r2, r3, r4;
        Scanner sc = new Scanner(System.in);
        System.out.println("Dame el número a");
        a = sc.nextDouble();
        System.out.println("Dame el número b");
        b = sc.nextDouble();
        System.out.println("Dame el número c");
        c = sc.nextDouble();
        System.out.println("Dame el número d");
        d = sc.nextDouble();
        
        r1=(a+b*38)/(c*d);
        r2=a+(30-b)/(c+d);
        r3=b*a*((a+b)/(b/d));
        r4=((a+50)/b)/(c/(4+d));
        
        System.out.println("El resultado 1 es: "+r1);
        System.out.println("El resultado 2 es: "+r2);
        System.out.println("El resultado 3 es: "+r3);
        System.out.println("El resultado 4 es: "+r4);
        
        
        
    }
    
}
