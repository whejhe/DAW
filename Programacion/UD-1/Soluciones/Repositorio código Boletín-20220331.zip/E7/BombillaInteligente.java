
package com.mycompany.u1.e7.bombilla;

public class BombillaInteligente {
    //propiedades
    public String marca;
    public int potencia;
    public boolean encendida;
    public int numVecesEncendida;
    
    //métodos
    public void cambiaMarca (String nuevaMarca){
        marca = nuevaMarca;
    }
    
    public void imprimeMarca (){
        System.out.println("La marca de la bombilla es: "+ marca);
    }
    public void cambiaPotencia (int nuevaPotencia){
        potencia = nuevaPotencia;
    }
    
    public void imprimePotencia (){
        System.out.println("La potencia de la bombilla es: "+ potencia);
    }
    
    public void encender(){
        encendida = true;
        //numVecesEncendida = numVecesEncendida +1;
        //numVecesEncendida +=1;
        numVecesEncendida ++;
    }
    public void apagar(){
        encendida = false;
    }
    public void imprimeEstado(){
        System.out.println("Encendida?: " + encendida);
    }
    
    public int obtieneNumVecesEncendida(){
        return numVecesEncendida;
    }
}
