package com.mycompany.u1.e7.bombilla;

public class PruebaBombillaInteligente {
    public static void main(String[] args) {
        
        BombillaInteligente led;
        led = new BombillaInteligente();
        
        led.imprimeMarca();
        led.imprimePotencia();
        
        led.cambiaMarca("Phillips");
        led.cambiaPotencia(100);
        
        led.encender();
        led.apagar();
        led.encender();
        
        led.imprimeMarca();
        led.imprimePotencia();
        led.imprimeEstado();
        
        /*int encendido;
        encendido = led.obtieneNumVecesEncendida();
        System.out.println("Se ha encendido: "+encendido+" veces");*/
        System.out.println("Se ha encendido: "+led.obtieneNumVecesEncendida()+" veces");
    }
    
}
