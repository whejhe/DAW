
package com.mycompany.u1.e5.vehiculo;

public class PruebaVehiculo {
    public static void main(String[] args) {
        Vehiculo fiesta;
        fiesta = new Vehiculo();
        
        fiesta.setNumRuedas(4);
        fiesta.setPotencia(100);
        fiesta.setConsumoPorKm(2);
        fiesta.reponerCombustible(100);
        
        fiesta.arrancar();
        fiesta.recorrerDistancia(30);
        fiesta.parar();
        
        fiesta.imprimeNumRuedas();
        fiesta.imprimePotencia();
        fiesta.imprimeConsumoPorKm();
        fiesta.imprimeLitrosEnDeposito();
        fiesta.imprimeAutonomiaEnKm();
    }
    
}
