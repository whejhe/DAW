
package com.mycompany.u1.e3.triangulo;

public class Triangulo {
    //Propiedades
    public double tamLado1;
    public double tamLado2;
    public double tamLado3;
    //Métodos
    public void cambiaLado1 (double nuevoLado){
        tamLado1 = nuevoLado;
    }
    
     public void cambiaLado2 (double nuevoLado){
        tamLado2 = nuevoLado;
    }
     
      public void cambiaLado3 (double nuevoLado){
        tamLado3 = nuevoLado;
    }
    
    public void imprimePerimetro(){
        System.out.println("El perímetro del triángulo es: " +(tamLado1 +tamLado2+tamLado3));
    }
    
    public void imprimeDescripcion(){
        System.out.println("Soy un triángulo y el tamaño de mis lados es lado1= " +tamLado1+ 
                ", lado2= " +tamLado2+ ", lado3= " +tamLado3);
    }
    
}
