package com.mycompany.u1.e1.pruebaabeja2;

//Ejercicio 1 de UD1 - Boletín de ejercicios
public class PruebaAbeja {
    public static void main(String[] args) {
        //Punto 1
        Abeja maya; //Definición
        maya = new Abeja();//Creación
        //Abeja maya = new Abeja();
        //Punto 2
        maya.vuela();
        maya.cambiaPosicionX(2);
        maya.cambiaPosicionY(0);
        maya.sePosa();
        maya.cambiaCargaNectar(1);
        
        //Punto 3
        maya.vuela();
        maya.cambiaPosicionX(2);//De este se puede prescindir
        maya.cambiaPosicionY(2);
        maya.sePosa();
        maya.cambiaCargaNectar(2);
        
        //Punto 4
        maya.vuela();
        maya.cambiaPosicionX(0);
        maya.cambiaPosicionY(2);//De este se puede prescindir
        maya.sePosa();
        maya.cambiaCargaNectar(3);
        
        //Punto 5
        maya.imprimePosicionX();
        maya.imprimePosicionY();
        maya.imprimeEstadoVuelo();
        maya.imprimeNumCargasNectar();
        maya.imprimePeso();
        
        
        
        
        
    }
    
    
}
