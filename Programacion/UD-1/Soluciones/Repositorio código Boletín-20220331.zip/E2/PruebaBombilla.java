package com.mycompany.u1.e2.bombilla;

public class PruebaBombilla {
    public static void main(String[] args) {
        Bombilla led;
        led = new Bombilla();
        
        led.imprimeMarca();
        led.imprimePotencia();
        
        led.cambiaMarca("Phillips");
        led.cambiaPotencia(100);
        
        led.encender();
        led.apagar();
        led.encender();
        
        led.imprimeMarca();
        led.imprimePotencia();
        led.imprimeEstado();
    }
    
}
