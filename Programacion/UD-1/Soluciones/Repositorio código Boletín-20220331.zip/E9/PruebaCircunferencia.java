package com.mycompany.u1.e9.circunferencia;

public class PruebaCircunferencia {
       public static void main(String[] args) {
           Circunferencia cir = new Circunferencia();
           cir.estableRadio(10);
           //System.out.println("El perímetro de la circuferencia es: " +cir.calculaPerimetro());
           double per=cir.calculaPerimetro();
           System.out.println("El perímetro de la circuferencia es: "+per);
           System.out.println("La superficie de la circuferencia es: " +cir.calculaSuperficie());
   
       }
    
}
