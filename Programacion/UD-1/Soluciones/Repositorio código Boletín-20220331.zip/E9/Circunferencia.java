
package com.mycompany.u1.e9.circunferencia;

public class Circunferencia {
    public double radio;
    public void estableRadio(double nuevoRadio){
        radio = nuevoRadio;
    }
    public double calculaPerimetro(){
        double perimetro = 2*Math.PI*radio;
        return perimetro;
    }
    public double calculaSuperficie(){
        //double superficie = Math.PI*radio*radio;
       /* double superficie = Math.PI*Math.pow(radio,2);
        return superficie;*/
       return Math.PI*Math.pow(radio,2);
    }
    
}
