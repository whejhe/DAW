
package com.mycompany.u1.e13.pruebascanner;
import java.util.Scanner;

public class PruebaScanner {
    public static void main(String[] args) {
        
        String nombre, apellido;
        int num1, num2;
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Dime tu nombre: ");
        nombre = sc.nextLine();
        
        
        System.out.println("Dime tu apellido: ");
        apellido = sc.nextLine();
        
        System.out.println("Dime un número entero: ");
        num1 = sc.nextInt();
        System.out.println("Dime otro número entero: ");
        num2 = sc.nextInt();
        
        System.out.println("Tu nombre es: "+nombre+ " y tu apellido es: "+apellido);
        int resSuma = num1 + num2;
        int resProducto = num1 * num2;
        
        System.out.println("Los números leídos son "+num1+" y "+num2+". Su suma es " +resSuma+ " y su producto es " +resProducto);
    }
    
}
