
package com.animales;

public class Animal {
    String tipo;
    int edad;
    String sexo;
    boolean patologia;

    public String getTipo() {
        return tipo;
    }

    public int getEdad() {
        return edad;
    }

    public String getSexo() {
        return sexo;
    }

    public boolean isPatologia() {
        return patologia;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public void setPatologia(boolean patologia) {
        this.patologia = patologia;
    }
    
}
