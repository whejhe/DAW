
package com.animales;

import java.util.Scanner;

public class SeviciosAnimales {
    public static void main(String[] args) {
        Animal ani=new Animal();
        Scanner sc = new Scanner(System.in);
        System.out.println("Indica el tipo de animal: perro, gato....");
        ani.setTipo(sc.nextLine());
        System.out.println("Indica la edad del animal");
        ani.setEdad(sc.nextInt());
        sc.nextLine();
        System.out.println("Indica el sexo del animal: M o H");
        ani.setSexo(sc.nextLine());
        System.out.println("Indica si el animal tiene alguna patología: true o false");
        ani.setPatologia(sc.nextBoolean());
        
        String tipo = ani.getTipo();
        int edad = ani.getEdad();
        String sexo = ani.getSexo();
        boolean patologia = ani.isPatologia();
        System.out.println("la patologia es :"+patologia);
        String servicio;
        if(tipo.equals("perro") && !patologia && edad>1){//peluquería
            servicio = "peluquería";
        }
        else{
            if((edad>=0 && edad<=1)&&tipo.equals("gato")&&(sexo.equals("H") || !patologia)){
                servicio ="guardería felina";
            }
            else{
                if(edad>1 && !(!patologia || tipo.equals("hamster")) && sexo.equals("H")){
                    servicio = "ecografía";
                }
                else{
                    servicio = "medicina";
                }
            }
        
        }
        System.out.println("Se ha contratado el servicio de "+servicio+" para el animal");
    }
    
}
