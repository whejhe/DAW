
package com.mycompany.u2.pe1repe.ejercicio2;

import java.util.Scanner;


public class MenuFormula {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a, b, c, porcentaje;
        final int D = 2;
        a= 10;
        b = 8;
        c = 2;
        System.out.println("MENU DE OPCIONES: ");
        System.out.println("1 - Calcula la fórmula usando la división entre enteros");
        System.out.println("2 - Calcula la fórmula usando la división entre números reales");
        System.out.println("3 - Calcula el porcentaje de descuento a la fórmula  entre números enteros. El porcentaje a aplicar se le solicita al usuario.");
        System.out.println("4 - Calcula el porcentaje de descuento a la fórmula  entre números reales. El porcentaje a aplicar se le solicitará al usuario");
        System.out.println("Escoge una opción: ");
        int opcion = sc.nextInt();
        
        switch(opcion){
            case 1:
                int op1 = ((a + b)/(c*c*D))+a-b;
                System.out.println("El resultado del cálculo es: "+op1);
                break;   
            case 2:
                double op2=((double)(a + b)/(c*c*D))+a-b;
                System.out.println("El resultado del cálculo es: "+op2);
                break;   
            case 3:
                System.out.println("Indica el porcentaje a aplicar a la fórmula");
                porcentaje = sc.nextInt();
                
                int op3 = (((a + b)/(c*c*D))+a-b)*porcentaje/100;
                System.out.println("El resultado del cálculo es: "+op3);
                break; 
            case 4:
                System.out.println("Indica el porcentaje a aplicar a la fórmula");
                porcentaje = sc.nextInt();
                double op4 = (((double)(a + b)/(c*c*D))+a-b)*porcentaje/100;
                System.out.println("El resultado del cálculo es: "+op4);
                break; 
            default:
                System.out.println("Opción incorrecta");
                
        }
        
        
    }
    
}
