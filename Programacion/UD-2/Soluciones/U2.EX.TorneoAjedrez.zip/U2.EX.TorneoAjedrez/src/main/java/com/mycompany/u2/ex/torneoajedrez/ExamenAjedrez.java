package com.mycompany.u2.ex.torneoajedrez;

import java.util.Scanner;

public class ExamenAjedrez {

    public static void main(String[] args) {
        String[] ajedrez = {"A2a4", "H7h5", "D2d4", "H5h3", "F1g3", "G8f6", "B2b4", "A7a5", "C2c4", "D5d3",
            "A1a3", "H8g6", "C2c4", "A5a3", "D1h3", "A8f8", "B2h2", "A7f3", "C2g6", "F5b3",
            "G2f4", "H7c5", "A2f4", "H3h8", "A1g3", "A5f6", "C7b4", "C4b5", "B4d5", "G5h3"};
        Scanner sc = new Scanner(System.in);
        int opcion;
        do {
            //pinta el menú

            System.out.println("0 - Salir");
            System.out.println("1 - Mostrar movimientos de las blancas");
            System.out.println("2 - Mostrar movimientos de las negras");
            System.out.println("3 - Mostrar todos los movimientos");
            System.out.println("4 - Buscar movimiento");
            System.out.println("Escoge una opcoón del menú");
            opcion = sc.nextInt();

            switch (opcion) {
                case 0://Salir
                    System.out.println("Adiós");
                    break;
                case 1://Mostrar movimientos de las blancas. Posiciones pares
                    System.out.println("Comienzo de los movimientos de las piezas blancas");
                    for (int i = 0; i < ajedrez.length; i++) {
                        if (i % 2 == 0) {//Si el resto es cero, es posición par
                            System.out.print(ajedrez[i] + " ");
                        }
                    }
                    System.out.println(" ");
                    System.out.println("Fin de los movimientos de las piezas blancas");
                    break;
                case 2://Mostrar movimientos de las negras. Posiciones impares
                    System.out.println("Comienzo de los movimientos de las piezas negras");
                    for (int i = 0; i < ajedrez.length; i++) {
                        if (i % 2 != 0) {//Si el resto no es cero, es posición impar
                            System.out.print(ajedrez[i] + " ");
                        }
                    }
                    System.out.println(" ");
                    System.out.println("Fin de los movimientos de las piezas negras");
                    break;
                case 3://Mostrar todos los movimientos
                    System.out.println("Movimientos de la partida:");
                    for (int i = 0; i < ajedrez.length; i++) {
                        if (i % 2 == 0) {//Si el resto es cero, es posición par. muestra blanca
                            System.out.println((i + 1) + " - Blancas - " + ajedrez[i]);
                        } else {//posición impar negras
                            System.out.println((i + 1) + " - Negras - " + ajedrez[i]);
                        }
                    }
                    break;
                case 4://Buscar movimiento
                    System.out.println("Indica qué movimiento quieres buscar");
                    sc.nextLine();//limpieza de entrada de caracteres
                    String movimiento = sc.nextLine();

                    int posicion = -1;
                    for (int i = 0; i < ajedrez.length; i++) {
                        if (ajedrez[i].equalsIgnoreCase(movimiento)) {
                            posicion = i;
                            break;
                        }
                    }
                    if (posicion == -1) {
                        System.out.println("Movimiento no encontrado");
                    } else {
                        if (posicion%2 == 0) {
                            System.out.println("Movimiento encontrado en la posición "+posicion+" correspondiente a las piezas blancas");
                        } else {
                            System.out.println("Movimiento encontrado en la posición "+posicion+" correspondiente a las piezas negras");
                        }
                    }
                    break;
                default:
                    System.out.println("Opción incorrecta");
            }
        } while (opcion != 0);

    }
}
