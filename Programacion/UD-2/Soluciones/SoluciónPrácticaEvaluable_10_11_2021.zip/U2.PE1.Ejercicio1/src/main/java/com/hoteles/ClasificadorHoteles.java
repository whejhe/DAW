
package com.hoteles;

import java.util.Scanner;

public class ClasificadorHoteles {
    public static void main(String[] args) {
        Hotel h = new Hotel();
        Scanner sc = new Scanner(System.in);
        System.out.println("Indica la distancia al centro de la ciudad medida en kilómetros:");
        h.setDistanciaCentro(sc.nextDouble());
        System.out.println("Indica si tiene piscina (true o false):");
        h.setPiscina(sc.nextBoolean());
        System.out.println("Indica si tiene la recepción abierta 24 horas (true o false):");
        h.setRecepcion(sc.nextBoolean());
        System.out.println("Indica el número de idiomas que se hablan en la recepción:");
        h.setNumIdiomas(sc.nextInt());
        double km = h.getDistanciaCentro();
        boolean piscina = h.isPiscina();
        boolean recepcion = h.isRecepcion();
        int idioma = h.getNumIdiomas();
        String categoria;
        
        //Categoría superior
        if(km<1 && idioma >=4 && piscina && recepcion){
            categoria = "superior";
        }
        else{
        //Categoría intermedia
            if((km>=1 && km<=3) && idioma>=4 && (piscina || recepcion)){
                categoria = "intermedia";
            }
            else{
                if ((km>3 && !(piscina || recepcion)) && idioma>=4){//Categoría básica
                    //if((km>3 && !piscina && !recepcion && idioma)
                    categoria = "básica";
                }
                else{//Categoría económica
                    categoria ="económica";
                }
            }
        }
        System.out.println("El hotel es de categoría "+categoria);
    }
    
}
