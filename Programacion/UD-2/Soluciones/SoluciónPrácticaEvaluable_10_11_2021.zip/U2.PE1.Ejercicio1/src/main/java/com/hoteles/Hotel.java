
package com.hoteles;

public class Hotel {
    public double distanciaCentro;//la distancia al centro de la ciudad medida en kilómetros
    public boolean piscina;//si tiene piscina
    public boolean recepcion;//si tiene la recepción abierta 24 horas
    public int numIdiomas;// el número de idiomas que se hablan en la recepción.

    public void setDistanciaCentro(double distanciaCentro) {
        this.distanciaCentro = distanciaCentro;
    }

    public void setPiscina(boolean piscina) {
        this.piscina = piscina;
    }

    public void setRecepcion(boolean recepcion) {
        this.recepcion = recepcion;
    }

    public void setNumIdiomas(int numIdiomas) {
        this.numIdiomas = numIdiomas;
    }

    public double getDistanciaCentro() {
        return distanciaCentro;
    }

    public boolean isPiscina() {
        return piscina;
    }

    public boolean isRecepcion() {
        return recepcion;
    }

    public int getNumIdiomas() {
        return numIdiomas;
    }
    
}
