
package com.mycompany.u2.pe1.menuformulas;

import java.util.Scanner;

public class MenuFormulas {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = 10;
        int b = 8;
        int c = 2;
        int d = 2;
        
        System.out.println("MENU DE OPCIONES: ");
        System.out.println("1 - Calcula la fórmula 1 usando la división entre enteros");
        System.out.println("2 - Calcula la fórmula 1 usando la división entre números reales");
        System.out.println("3 - Calcula la fórmula 2 usando la división entre enteros");
        System.out.println("4 - Calcula la fórmula 2 usando la división entre números reales");
        System.out.println("Escoge una opción: ");
        int opcion = sc.nextInt();
        
        switch(opcion){
            case 1:
                int op1 = a + ((30-b)/(c+d));
                System.out.println("El resultado del cálculo es: "+op1);
                break;   
            case 2:
                double op2=a + ((double)(30-b)/(c+d));
                System.out.println("El resultado del cálculo es: "+op2);
                //break;   
            case 3:
                int op3 = (a+b*38)/(c*d);
                System.out.println("El resultado del cálculo es: "+op3);
                break; 
            case 4:
                double op4 = (double)(a+b*38)/(c*d);
                System.out.println("El resultado del cálculo es: "+op4);
                break; 
            default:
                System.out.println("Opción incorrecta");
                
        }
        
    }
    
    
}
