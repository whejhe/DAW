
package es.tuespiral.programacionfuncional.e.aplicacion;

import java.util.List;

/* Este nuevo enfoque tiene beneficia también al código de Java clásico 
   (anterior a Java 8) ya que elimina código redundante. Se suele encontrar 
   sobre todo al definir distintos criterios de orden en colecciones de elementos.

   Sin embargo, el gran beneficio lo encontraremos cuando lo veamos combinado 
   con el API Streams.
 */
public class FuncionesJavaClasico {
    public static void main(String[] args) {
        List<Empleado> lista = Empleado.listAll();
        
        // Supongamos que queremos ordenar la lista de empleados con distintos 
        // criterios de orden. Con el Java clásico tendríamos que hacer 
        // una clase que implemente la interfaz Comparator para cada criterio
        // de orden. Esto provocaría que nuestro proyecto se "ensucie" con muchos 
        // ficheritos que solo expresan un criterio de orden que quizás solo 
        // se usa una vez en el proyecto.
        
        // Veamos cómo lo haríamos con el paradigma funcional sin tener que crear
        // una clase para cada criterio de orden
        System.out.println("Ordenada por nombre ascendente");
        lista.sort( (e1, e2) -> e1.getNombre().compareTo(e2.getNombre()) );
        imprimeLista(lista);
        
        System.out.println("\nOrdenada por nombre descendente");
        lista.sort( (e1, e2) -> -e1.getNombre().compareTo(e2.getNombre()) );
        imprimeLista(lista);
        
        System.out.println("\nOrdenada por antigüedad ascendente");
        lista.sort( (e1, e2) -> e1.getAntiguedad() - e2.getAntiguedad() );
        imprimeLista(lista);
        
        System.out.println("\nOrdenada por departamento y nombre del empleado");
        lista.sort( (e1, e2) -> {
                int resultado = e1.getDepartamento().compareTo(e2.getDepartamento());
                if (resultado != 0)
                    return resultado;
                else 
                    return e1.getNombre().compareTo(e2.getNombre());
                });
        imprimeLista(lista);
        
        
    }
    
    public static void imprimeLista(List<Empleado> lista) {
        for(Empleado e : lista) {
            System.out.println(e);
        }
    }
}
