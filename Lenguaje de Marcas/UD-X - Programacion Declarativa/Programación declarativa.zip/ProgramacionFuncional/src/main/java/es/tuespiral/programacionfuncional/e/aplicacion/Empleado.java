package es.tuespiral.programacionfuncional.e.aplicacion;

import java.util.ArrayList;
import java.util.List;

public class Empleado {
    private String nombre, departamento;
    private int antiguedad;
    private double salario;

    public Empleado(String nombre, String departamento, int antiguedad, double salario) {
        this.nombre = nombre;
        this.departamento = departamento;
        this.antiguedad = antiguedad;
        this.salario = salario;
    }
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public int getAntiguedad() {
        return antiguedad;
    }

    public void setAntiguedad(int antiguedad) {
        this.antiguedad = antiguedad;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    @Override
    public String toString() {
        return "Empleado{" + "nombre=" + nombre + ", departamento=" + departamento + ", antiguedad=" + antiguedad + ", salario=" + salario + '}';
    }
    
    public static List<Empleado> listAll() {
        List<Empleado> lista = new ArrayList<>();
        
        lista.add(new Empleado("Pedro", "Contabilidad", 5, 2000));
        lista.add(new Empleado("Juan", "Recursos Humanos", 1, 2000));
        lista.add(new Empleado("María", "Dirección", 6, 3000));
        lista.add(new Empleado("Anabel", "Tecnológico", 2, 1500));
        lista.add(new Empleado("Tomás", "Contabilidad", 4, 1600));
        lista.add(new Empleado("Samuel", "Dirección", 1, 2100));
        lista.add(new Empleado("Irene", "Recursos Humanos", 3, 1700));
        lista.add(new Empleado("Laura", "Tecnológico", 8, 2000));
        lista.add(new Empleado("Gonzalo", "Tecnológico", 8, 2000));
        
        return lista;
    }
    
}
