package es.tuespiral.programacionfuncional.a.base;

import java.util.function.Function;

/* Con el paradigma de programación funcional, los métodos/funciones
   pasan a ser "ciudadanos de primera clase" y pueden ser asignados
   a variables y también pasados o devueltos como parámetros a un 
   método.
*/
public class ProgramacionFuncional {
    public static void main(String[] args) {
        System.out.println("Enfoque clásico: "+incrementaClasico(4));
        
        // Tipo de dato Function    nombreVariable   = notación Lambda
        Function<Integer, Integer> funcionIncrementa = num -> num + 1; 
        //                                    paramEntrada -> expresión a devolver
        
        System.out.println("Enfoque funcional: "+funcionIncrementa.apply(4));
    }
    
    public static Integer incrementaClasico(Integer num) {
        return num+1;
    }
    
    // En Java 8 se llama 'interfaz funcional' a cualquier interfaz que tiene
    // 1 y solo 1 método abstracto (sin código alguno). 
    
    // Si vemos cómo se define Function en la documentación de Java: 
    // https://docs.oracle.com/javase/8/docs/api/java/util/function/Function.html
    // resulta que Function<T, R> es una interfaz funcional que tiene un método 
    // abstracto R apply(T t) capaz de recibir un parámetro de entrada de tipo T 
    // y devolver otro de salida de tipo R.
    
    // Lo que hace el compilador cuando le asignamos la expresión lambda 
    // (num -> num + 1) a nuestra variable funcionIncrementa es inyectar 
    // ese código en el método abstracto apply 
    
}
