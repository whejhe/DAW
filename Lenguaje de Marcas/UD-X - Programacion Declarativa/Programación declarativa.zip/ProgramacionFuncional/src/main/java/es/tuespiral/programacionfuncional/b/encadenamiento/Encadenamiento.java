package es.tuespiral.programacionfuncional.b.encadenamiento;

import java.util.function.Function;

/* El paradigma funcional permite encadenar funciones y asignarlas
   a otras funciones 
*/
public class Encadenamiento {
    public static void main(String[] args) {
        
        Function<Integer, Integer> funcIncrementa = num -> num + 1; 
        Function<Integer, Integer> funcDuplica = num -> num * 2; 
        
        Function<Integer, Integer> funcDuplicaMasUno = funcDuplica.andThen(funcIncrementa);
        Function<Integer, Integer> funcMasUnoYDuplica = funcDuplica.compose(funcIncrementa);
        
        System.out.println("Duplica y suma 1: "+funcDuplicaMasUno.apply(4));
        System.out.println("Suma 1 y duplica: "+funcMasUnoYDuplica.apply(4));
    }
    
}
