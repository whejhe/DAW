package es.tuespiral.programacionfuncional.c.tipos;

import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.BiPredicate;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;


/* El paquete java.util.function define un montón de tipos de funciones:
   - Function: toma un parámetro de entrada y devuelve otro de salida
   - Predicate: toma un parámetro de entrada y devuelve un boolean
   - Consumer: toma un parámetro de entrada y no devuelve nada (void)
   - Supplier: no toma parámetro de entrada y devuelve algo
   - BiFunction: toma dos parámetros de entrada y devuelve otro de salida
   - BiPredicate: toma dos parámetros de entrada y devuelve un boolean
   - BiConsumer: toma dos parámetros de entrada y no devuelve nada (void)
   - ...
*/
public class TiposDeFunciones {
    public static void main(String[] args) {
        
        Predicate<Integer> funcEsPar = num -> num % 2 == 0; 
        System.out.println("Predicate: "+funcEsPar.test(80));
        
        
        Consumer<Integer> imprime = num -> System.out.println("El número es: "+num);
        imprime.accept(100);
        
        
        // Si la función no tiene parámetros de entrada podemos ()
        Supplier<Integer> aleatorioMenor1000 = () -> (int) (Math.random()*1000.0);
        System.out.println("Genera aleatorio: "+aleatorioMenor1000.get());
        
        
        // Si la función tiene más de un parámetro de entrada los ponemos entre ()
        BiFunction<Integer, Integer, Integer> funcSuma = (num1, num2) -> num1+num2;
        System.out.println("BiFunction: "+funcSuma.apply(3, 3));
        
        
        BiPredicate<Integer, Integer> funcMayorQue = (num1, num2) -> Integer.compare(num1, num2) > 0;
        System.out.println("BiPredicate: "+funcMayorQue.test(4, 1));
        
        
        // Si queremos que la función haga varias cosas podemos escribir 
        // más líneas si las encerramos entre {}
        BiConsumer<Integer, Integer> imprimeAleatorioEnRango = 
                (inferior, superior) -> {
                    int num = (int) (Math.random()*superior) + inferior;
                    System.out.println("El número aleatorio generado es: "+num);
                };
        imprimeAleatorioEnRango.accept(10, 100);
        
    }
    
}
