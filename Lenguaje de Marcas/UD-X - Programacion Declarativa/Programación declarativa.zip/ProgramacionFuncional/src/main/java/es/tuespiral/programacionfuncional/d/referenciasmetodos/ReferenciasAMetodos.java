package es.tuespiral.programacionfuncional.d.referenciasmetodos;

import java.util.function.Consumer;
import java.util.function.Supplier;

/* Java 8 también permite usar métodos ya existentes en el API 
   como funciones. Estos métodos solo pueden ser estáticos y se usa la 
   notación: Clase::métodoEstático
*/
public class ReferenciasAMetodos {
    public static void main(String[] args) {
        
        // Esta es la referencia a método que más vamos a usar
        Consumer<Object> imprime = System.out::println; 
        
        imprime.accept("Imprimiendo desde una función con una referencia a método del API de Java");
        
        // Otro ejemplo:
        Supplier<Double> generaAleatorio = Math::random;
        imprime.accept("Número aleatorio generado: "+generaAleatorio.get());
        
    }
    
    
}
