package es.tuespiral.streams.d.operacionesterminales;

import es.tuespiral.streams.empleados.Empleado;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/*  Decíamos que el flujo de trabajo habitual con streams era:
     1.- Partir de una colección de elementos
     2.- Extraer un stream
     3.- Realizar alguna de las operaciones "intermedias" (filter, map, distinct...)
     4.- Realizar alguna operación "terminal" que cierra el stream. Ahora vamos
         a fijarnos en otra operaciones que no sean el FOREACH. Vamos a ver:
        - Cómo realizar búsquedas con los streams con FINDFIRST
        - Cómo reducir un stream a un solo valor con REDUCE (sumatorio, máximo, mínimo...)                
        - Cómo recolectar los valores de un stream y guardarlos en una colección con COLLECT        
*/
public class OperacionesTerminales {

    public static void main(String[] args) {

        List<Empleado> lista = Empleado.listAll();

        // BÚSQUEDA DE UN ELEMENTO QUE CUMPLA UNA CONDICIÓN
        // Buscamos el primer empleado con nombre Tomás:
        Optional<Empleado> buscarTomas = lista.stream()
              .filter(elem -> elem.getNombre().equalsIgnoreCase("Tomás"))
              .findFirst(); // Corta el flujo en cuanto encuentra el primero
        
        // Como puede que lo encontremos o no, Java 8 trae una clase
        // contenedora llamada Optional que puede contener un elemento
        // o un nulo. Esta clase también tiene métodos que nos permiten
        // averiguar qué resultado hemos obtenido. Ejemplos:
        System.out.println("Resultado búsqueda del empleado 'Tomás': "+ 
                buscarTomas.orElse(new Empleado("No encontrado", "No encontrado", 0, 0)));
        
        // Otro uso. Esta vez solo imprime si lo encuentra. Si se devuelve un
        // null no se realiza ninguna acción
        // buscarTomas.ifPresent(System.out::println); 
        System.out.println("-------------------------");
        
        
        Optional<Empleado> buscarPaco = lista.stream()
              .filter(elem -> elem.getNombre().equalsIgnoreCase("Paco"))
              .findFirst(); 
        
        System.out.println("Resultado búsqueda del empleado 'Paco': "+ 
               buscarTomas.orElse(new Empleado("No encontrado", "No encontrado", 0, 0)));
        System.out.println("-------------------------");
        

        // REDUCIR UN STREAM A UN SOLO VALOR
        // Calculamos la suma de los salarios de todos los empleados de la empresa
        double sumaSalarios = lista.stream()
              .map(elem -> elem.getSalario())
              .reduce(0.0, (suma, elem) -> suma + elem);
        System.out.println("La suma de los salarios de los empleados de la empresa es: "+sumaSalarios);
        System.out.println("-------------------------");
        

        // Calculamos el salario máximo. En este caso la operación max devuelve
        // null si el stream está vacío. Por eso el tipo de retorno es un Optional
        Optional<Double> salarioMax = lista.stream()
              .map(elem -> elem.getSalario())
              .max((e1, e2) -> Double.compare(e1, e2));
        System.out.println("El salario más alto de la empresa es: "+salarioMax.orElse(0.0));
        System.out.println("-------------------------");
        
        
        // RECOLECTAR LOS ELEMENTOS DE UN STREAM EN UNA COLECCIÓN
        // Vamos a crear una lista de los elementos resultantes del procesado del stream
        System.out.println("Creamos una lista con los distintos nombres de los departamentos");
        List<String> listaDepartamentos = lista.stream()
             .map(e -> e.getDepartamento())
             .distinct()
             .collect(Collectors.toList());
        
        System.out.println("Y ahora la imprimimos:");
        listaDepartamentos.stream().forEach(System.out::println);
        

    }

    
}
