package es.tuespiral.streams.c.flujotrabajo;

import es.tuespiral.streams.empleados.Empleado;
import java.util.List;

/*  El flujo de trabajo habitual con streams es el siguiente
     1.- Partir de una colección de elementos
     2.- Extraer un stream
     3.- Realizar alguna de las operaciones "intermedias":
         - Filtrar los elementos con FILTER    
         - Transformar los elementos con MAP
         - Ordenar con SORTED
         - Quitar duplicados con DISTINCT
         - Limitar el número de resultados con LIMIT
     4.- Realizar alguna operación "terminal" que cierra el stream:
         - Aplicar un tratamiento final a cada elemento con FOREACH
         - ... Hay más operaciones terminales pero las veremos más adelante
*/
public class FlujoTrabajoHabitual {

    public static void main(String[] args) {

        List<Empleado> lista = Empleado.listAll();

        
        System.out.println("Nombre ordenado alfabéticamente de los empleados "
                + "con menos de 2 años de antigüedad o con salarios > 2000 euros");
        lista.stream()                  // <- Extraer el stream de una colección
             .filter(elem -> elem.getAntiguedad() < 2 ||  // <- Oper. intermedia
                             elem.getSalario() > 2000) 
             .map(elem -> elem.getNombre())    // <- Oper. intermedia
             .sorted()                         // <- Oper. intermedia
             .forEach(System.out::println);    // <- Oper. terminal
        
        
        System.out.println("-------------------------");
        System.out.println("Imprimir los distintos nombres de los departamentos en mayúsculas");
        lista.stream()                  // <- Extraer el stream de una colección
             .map(e -> e.getDepartamento())  // <- Oper. intermedia
             .map(String::toUpperCase)       // <- Oper. intermedia
             .distinct()                     // <- Oper. intermedia
             .forEach(System.out::println);  // <- Oper. terminal
        
        
        System.out.println("-------------------------");
        System.out.println("Imprimir los 3 empleados con más antigüedad en la empresa:");
        lista.stream()                  
             .sorted( (e1, e2) -> -Integer.compare(e1.getAntiguedad(), e2.getAntiguedad()))
             .limit(3)
             .forEach(System.out::println);  // <- Oper. terminal

    }

}
