package es.tuespiral.streams.b.caracteristicas;

import es.tuespiral.streams.empleados.Empleado;
import java.util.List;
import java.util.stream.Stream;


/* Un Stream solo se puede RECORRER 1 VEZ Y NO SE PUEDEN MODIFICAR (INMUTABLES) */
public class Caracteristicas {

    public static void main(String[] args) {

        List<Empleado> lista = Empleado.listAll();

        Stream<Empleado> empleados = lista.stream();

        // Intenta averiguar qué hace esta cadena de streams
        empleados.filter(elem -> elem.getSalario() > 2000)
             .map(elem -> elem.getNombre())
             .filter(elem -> elem.contains("a"))
             .map(String::toUpperCase)
             .forEach(System.out::println);
        System.out.println("-----------------");
        

        // Equivalente en programación imperativa:
//        for (Empleado elem : lista) {
//            if (elem.getSalario() > 2000 && elem.getNombre().contains("a")) {
//                System.out.println(elem.getNombre().toUpperCase());
//            }
//        }


        // UN STREAM SOLO SE PUEDE RECORRER UNA VEZ
        // Si intentamos recorrer nuestro stream 'empleados' una segunda vez
        // obtendríamos una IllegalStateException
        empleados.forEach(System.out::println);
        
        
        // SON INMUTABLES
        // Con esto queremos decir que una vez creados no disponemos
        // de operaciones para añadir o quitar elementos... podemos crear
        // un stream a partir de otro pero no modificar uno existente.
        
        // Si tomamos un stream y ponemos un . para que el IDE nos diga
        // los métodos disponibles no encontraremos ninguno tipo add, delete, insert, modify...
        // insert, modify... Observa:
        Stream<Empleado> streamEmpleados = lista.stream();
        //streamEmpleados.
        
        // LAS FUENTES SÍ SON MUTABLES Y EL STREAM "VE" LOS CAMBIOS
        // Las colecciones (listas, conjuntos...) sí que son mutables y podemos
        // añadir/quitar/... elementos. Lo interesante es que el Stream se 
        // mantiene conectado a la colección "fuente" y "ve los cambios que
        // se han realizado sobre ésta.
        lista.add(new Empleado("Juan Sin Miedo", "Recursos Humanos", 3, 2000));
        streamEmpleados.forEach(System.out::println);
    }
}
