package es.tuespiral.streams.a.primerospasos;

import es.tuespiral.streams.empleados.Empleado;
import java.util.List;
import java.util.stream.Stream;

public class StreamDemo {

    public static void main(String[] args) {

        // Tenemos una lista de objetos Empleado
        List<Empleado> lista = Empleado.listAll();

        // Le pedimos un stream de Empleado a la lista
        Stream<Empleado> empleados = lista.stream();

        // Del stream anterior sacamos otro stream pero nos quedamos
        // solo con los empleados que ganan más de 2000 euros
        Stream<Empleado> empleadosMas2000 = empleados.filter(elem -> elem.getSalario() > 2000);
        
        // Del stream anterior sacamos otro stream con los nombres
        // de los empleados
        Stream<String> nombres = empleadosMas2000.map(elem -> elem.getNombre());

        // Imprimimos el stream de nombres
        nombres.forEach(System.out::println);

        
        System.out.println("-------------------------");
        // Sin embargo todo lo anterior se suele escribir encadenado
        // de la siguiente forma:
        lista.stream()
             .filter(elem -> elem.getSalario() > 2000)
             .map(elem -> elem.getNombre())
             .forEach(System.out::println);
        
        
        // Fíjate que la notación anterior es mezcla dos paradigmas:
        // DECLARATIVO: decimos qué queremos hacer y no cómo se tiene que hacer
        // Igual que hacemos con SELECT * FROM... en SQL
        // FUNCIONAL: las funciones ahora se consideran como variables
        // que pueden pasarse a los métodos como parámetros.
        // El paradigma que hemos estado viendo durante el curso se
        // llama paradigma IMPERATIVO porque tenemos que dar órdenes
        // diciendo cómo hacer las cosas, pero no siempre queda muy 
        // claro en el código qué estamos haciendo.
        // Compara el código anterior con su equivalente en programación
        // imperativa:
//        for (Empleado elem : lista) {
//            if (elem.getSalario() > 2000) {
//                System.out.println(elem.getNombre());
//            }
//        }
    
    }
    
}
