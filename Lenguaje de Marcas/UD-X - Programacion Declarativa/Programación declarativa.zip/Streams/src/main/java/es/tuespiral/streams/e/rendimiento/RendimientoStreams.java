package es.tuespiral.streams.e.rendimiento;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class RendimientoStreams {
    public static void main(String[] args) {
        Random rand = new Random();
        List<Integer> lista = new ArrayList<>();
        
        System.out.println("Creando el juego de datos");
        // Probar con números más grandes y más pequeños
        for (int i = 1; i < 10000000; i++) {
            lista.add(rand.nextInt());
        }
        
        System.out.println("Midiendo tiempos del ArrayList...");
        long sumaArray = 0;
        long antesArray = System.nanoTime();
        for(Integer entero : lista) {
            sumaArray = sumaArray + entero;
        }
        long despuesArray = System.nanoTime();
        long tiempoArray = despuesArray - antesArray;
        System.out.println("Duración con for each: "+tiempoArray+" nanosegundos");
        
        System.out.println("Midiendo tiempos del stream...");
        long antesStream = System.nanoTime();
        long sumaStream = lista.stream().reduce(0, (suma, elem) -> suma+elem);
        long despuesStream = System.nanoTime();
        long tiempoStream = despuesStream - antesStream;
        System.out.println("Duración con stream: "+tiempoStream+" nanosegundos");
        
        System.out.println("Midiendo tiempos del stream paralelo...");
        long antesParStream = System.nanoTime();
        long sumaParStream = lista.parallelStream().reduce(0, (suma, elem) -> suma+elem);
        long despuesParStream = System.nanoTime();
        long tiempoParStream = despuesParStream - antesParStream;
        System.out.println("Duración con stream paralelo: "+tiempoParStream+" nanosegundos");
        
        
        long diferencia = tiempoStream - tiempoArray;
        double numVeces = (double)diferencia/tiempoArray;
        System.out.println("\nEl proceso con streams es "+numVeces+" veces más lento que con ArrayList");
        
        long diferenciaParalelo = tiempoParStream - tiempoArray;
        double numVecesParalelo = (double)diferenciaParalelo/tiempoArray;
        System.out.println("\nEl proceso con stream paralelo es "+numVecesParalelo+" veces más lento que con ArrayList");
        
        long diferenciaStreams = tiempoStream - tiempoParStream;
        double numVecesStreams = (double)diferenciaStreams/tiempoParStream;
        System.out.println("\nEl proceso con stream es "+numVecesStreams+" veces más lento que con stream paralelos");

    }
}
