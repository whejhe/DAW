function insertar() {
    // Extraemos el texto del 'input'
    let texto = document.getElementById("texto").value;

    // Borramos lo que hubiera en el 'input'
    document.getElementById("texto").value = "";

    if (texto !== "") {
        // Creamos una etiqueta 'li'
        let elem = document.createElement("li");
        // Creamos un nodo de tipo texto con el valor escrito por el usuario
        let nodoTexto = document.createTextNode(texto);
        // Rellenamos la etiqueta 'li' con el texto anterior
        elem.append(nodoTexto);
        // Añadimos el elemento 'li' a su 'ul'
        document.getElementById("lista").append(elem);

        // Ocultamos el warning
        document.getElementById("warning").style.display = "none";
        // Ocultamos el texto cuando no hay pensamientos
        document.getElementById("no-piensa").style.display = "none";
        // Mostramos el botón de eliminar pensamientos
        document.getElementById("eliminar").style.display = "inline-block";
        // Ocultamos la imagen del cerebro
        document.getElementById("img-cerebro").style.display = "none";
    } else {
        document.getElementById("warning").style.display = "block";
    }
}

function eliminar() {
    lista = document.getElementById("lista");
    
    while (lista.lastChild) {
        lista.removeChild(lista.lastChild);
    }
    
    // Ocultamos el botón de eliminar pensamientos
    document.getElementById("eliminar").style.display = "none";
    // Mostramos el texto cuando no hay pensamientos
    document.getElementById("no-piensa").style.display = "inline-block";
    // Mostramos la imagen del cerebro
    document.getElementById("img-cerebro").style.display = "block";
}