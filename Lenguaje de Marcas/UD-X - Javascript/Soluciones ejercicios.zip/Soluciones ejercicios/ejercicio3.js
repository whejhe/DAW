let nombre = prompt("Dime tu nombre: ");
let apellido1 = prompt("Dime tu primer apellido: ");
let apellido2 = prompt("Dime tu segundo apellido: ");
console.log("Te llamas "+nombre+" "+apellido1+" "+apellido2);