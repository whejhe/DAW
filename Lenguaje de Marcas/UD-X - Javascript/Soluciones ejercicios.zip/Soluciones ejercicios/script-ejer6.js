document.write("<h1>Hola mundo</h1>");
alert("Este mensaje va a la consola");